# Diamond Casino Podium Vehicle

This is the directory for vehicles from the Diamond Casino, traditionally won through spinning the Lucky Wheel and landing on the Vehicle tab.  
These versions, however, are copied directly from the podium.
