# Exotic Exports Vehicles

Exotic Exports vehicles spawn somewhat randomly at predetermined locations after the completion of your first contract with the Auto Shop property.  
They're also incredibly awkward to name, since many are the same type as others. These have been numbered based on their paint job color numbers; if they have a secondary color, it is listed after the hyphen.
