# Character Cars

Some characters in the game have cars.  
Some players try to catalog them.  
I'll give you a guess who I'm referring to with the second category.
