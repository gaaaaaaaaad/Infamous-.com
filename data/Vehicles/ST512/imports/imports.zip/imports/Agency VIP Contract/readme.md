# The Contract

Vehicles in this folder are archival copies of cars that appear throughout the VIP Contract, as well as Tanisha and Franklin's cars from in front of their house.
