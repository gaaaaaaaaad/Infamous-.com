# LS Car Meet Prize Rides

These cars are traditionally unlocked by completing certain challenges, often finishing above a certain rank in a set number of races.  
These particular copies are pulled straight from the back of the Slamtruck display.
