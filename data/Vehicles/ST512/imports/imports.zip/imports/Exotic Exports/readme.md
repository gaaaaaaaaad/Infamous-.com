## Exotic Exports Vehicles

Exotic Exports vehicles spawn somewhat randomly at predetermined locations after the completion of your first contract with the Auto Shop property.  
These have been saved by model, with a parenthetical listing of the primary and secondary colors afterwards.
