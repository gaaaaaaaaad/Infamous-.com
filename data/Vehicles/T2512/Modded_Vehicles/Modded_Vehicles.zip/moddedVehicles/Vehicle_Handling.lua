--Big thanks to Proddy#7272 for all the lua help with this :)
local handlingproperties = {
    "fMass",
	"fInitialDragCoeff",
    "fDownforceMod",
    "fPercentSubmerged",
    "fAcceleration",
    "btInitialDriveGears",
    "fDriveInertia",
    "fClutchChangeRateScaleUpShift",
    "fClutchChangeRateScaleDownShift",
    "fInitialDriveForce",
    "fDriveMaxFlatVel",
    "fInitialDriveMaxFlatVel",
    "fBrakeForce",
    "fBrakeBiasFront",
    "fBrakeBiasRear",
    "fHandBrakeForce",
    "fSteeringLock",
    "fSteeringLockRatio",
    "fTractionCurveMax",
    "fTractionCurveMaxRatio",
    "fTractionCurveMin",
    "fTractionCurveMinRatio",
    "fTractionCurveLateral",
    "fTractionCurveLateralRatio",
    "fTractionSpringDeltaMax",
    "fTractionSpringDeltaMaxRatio",
    "fLowSpeedTractionLossMult",
    "fCamberStiffnesss",
    "fTractionBiasFront",
    "fTractionBiasRear",
    "fTractionLossMult",
    "fSuspensionForce",
    "fSuspensionCompDamp",
    "fSuspensionReboundDamp",
    "fSuspensionUpperLimit",
    "fSuspensionLowerLimit",
    "fSuspensionRaise",
    "fAntiRollBarForce",
    "fRollCentreHeightFront",
    "fRollCentreHeightRear",
    "fCollisionDamageMult",
    "fWeaponDamageMult",
    "fDeformationDamageMult",
    "fEngineDamageMult",
    "fPetrolTankVolume",
    "fOilVolume",
    "fRocketMaxEnergy",
    "fRocketBoostSpeed",
	"fBuoyancyConstant",
	"fPetrolConsumptionRate"
}

local carhandlingdata = {
    "fBackEndPopUpCarImpulseMult",
    "fBackEndPopUpBuildingImpulseMult",
    "fBackEndPopUpMaxDeltaSpeed",
    "fToeFront",
    "fToeRear",
    "fCamberFront",
    "fCamberRear",
    "fCastor",
    "fEngineResistance",
    "fMaxDriveBiasTransfer",
    "fJumpForceScale",
    "fIncreasedRammingForceScale"
}

local strAdvancedFlags = {
	["CF_DIFF_FRONT"] = 1 << 0,
	["CF_DIFF_REAR"] = 1 << 1,
	["CF_DIFF_CENTRE"] = 1 << 2,
	["CF_DIFF_LIMITED_FRONT"] = 1 << 3,
	["CF_DIFF_LIMITED_REAR"] = 1 << 4,
	["CF_DIFF_LIMITED_CENTRE"] = 1 << 5,
	["CF_DIFF_LOCKING_FRONT"] = 1 << 6,
	["CF_DIFF_LOCKING_REAR"] = 1 << 7,
	["CF_DIFF_LOCKING_CENTRE"] = 1 << 8,
	["CF_GEARBOX_FULL_AUTO"] = 1 << 9,
	["CF_GEARBOX_MANUAL"] = 1 << 10,
	["CF_GEARBOX_DIRECT_SHIFT"] = 1 << 11,
	["CF_GEARBOX_ELECTRIC"] = 1 << 12,
	["CF_ASSIST_TRACTION_CONTROL"] = 1 << 13,
	["CF_ASSIST_STABILITY_CONTROL"] = 1 << 14,
	["CF_ALLOW_REDUCED_SUSPENSION_FORCE"] = 1 << 15,
	["CF_HARD_REV_LIMIT"] = 1 << 16,
	["CF_HOLD_GEAR_WITH_WHEELSPIN"] = 1 << 17,
	["CF_INCREASE_SUSPENSION_FORCE_WITH_SPEED"] = 1 << 18,
	["CF_BLOCK_INCREASED_ROT_VELOCITY_WITH_DRIVE_FORCE"] = 1 << 19,
	["CF_REDUCED_SELF_RIGHTING_SPEED"] = 1 << 20,
	["CF_CLOSE_RATIO_GEARBOX"] = 1 << 21,
	["CF_FORCE_SMOOTH_RPM"] = 1 << 22,
	["CF_ALLOW_TURN_ON_SPOT"] = 1 << 23,
	["CF_CAN_WHEELIE"] = 1 << 24,
	["CF_ENABLE_WHEEL_BLOCKER_SIDE_IMPACTS"] = 1 << 25,
	["CF_FIX_OLD_BUGS"] = 1 << 26,
	["CF_USE_DOWNFORCE_BIAS"] = 1 << 27,
	["CF_REDUCE_BODY_ROLL_WITH_SUSPENSION_MODS"] = 1 << 28,
	["CF_ALLOWS_EXTENDED_MODS"] = 1 << 29
}

local strModelFlags = {
	["MF_IS_VAN"] = 1 << 0,
	["MF_IS_BUS"] = 1 << 1,
	["MF_IS_LOW"] = 1 << 2,
	["MF_IS_BIG"] = 1 << 3,
	["MF_ABS_STD"] = 1 << 4,
	["MF_ABS_OPTION"] = 1 << 5,
	["MF_ABS_ALT_STD"] = 1 << 6,
	["MF_ABS_ALT_OPTION"] = 1 << 7,
	["MF_NO_DOORS"] = 1 << 8,
	["MF_TANDEM_SEATING"] = 1 << 9,
	["MF_SIT_IN_BOAT"] = 1 << 10,
	["MF_HAS_TRACKS"] = 1 << 11,
	["MF_NO_EXHAUST"] = 1 << 12,
	["MF_DOUBLE_EXHAUST"] = 1 << 13,
	["MF_NO_1STPERSON_LOOKBEHIND"] = 1 << 14,
	["MF_CAN_ENTER_IF_NO_DOOR"] = 1 << 15,
	["MF_AXLE_F_TORSION"] = 1 << 16,
	["MF_AXLE_F_SOLID"] = 1 << 17,
	["MF_AXLE_F_MCPHERSON"] = 1 << 18,
	["MF_ATTACH_PED_TO_BODYSHELL"] = 1 << 19,
	["MF_AXLE_R_TORSION"] = 1 << 20,
	["MF_AXLE_R_SOLID"] = 1 << 21,
	["MF_AXLE_R_MCPHERSON"] = 1 << 22,
	["MF_DONT_FORCE_GRND_CLEARANCE"] = 1 << 23,
	["MF_DONT_RENDER_STEER"] = 1 << 24,
	["MF_NO_WHEEL_BURST"] = 1 << 25,
	["MF_INDESTRUCTIBLE"] = 1 << 26,
	["MF_DOUBLE_FRONT_WHEELS"] = 1 << 27,
	["MF_IS_RC"] = 1 << 28,
	["MF_DOUBLE_REAR_WHEELS"] = 1 << 29,
    ["MF_NO_WHEEL_BREAK"] = 1 << 30,
    ["MF_IS_HATCHBACK"] = 1 << 31
}

local strDamageFlags = {
	["DF_DRIVER_SIDE_FRONT_DOOR"] = 1 << 0,
	["DF_DRIVER_SIDE_REAR_DOOR"] = 1 << 1,
	["DF_DRIVER_PASSENGER_SIDE_FRONT_DOOR"] = 1 << 2,
	["DF_DRIVER_PASSENGER_SIDE_REAR_DOOR"] = 1 << 3,
	["DF_BONNET"] = 1 << 4,
	["DF_BOOT"] = 1 << 5
}

local AIHandlingNames = {
    "TRUCK",
    "AVERAGE",
    "CRAP"
}


--Parents
local MainParent = menu.add_feature("Vehicle Handling Editor", "parent", 0)
local vCarHandlingparent = menu.add_feature("Car Handling Class", "parent", MainParent.id)
local vVehicleHandlingParent = menu.add_feature("Vehicle Handling Class", "parent", MainParent.id)
local vStrAdvancedFlagsParent = menu.add_feature("Advanced Flags", "parent", vCarHandlingparent.id)
local vstrModelFlagsParent = menu.add_feature("strModelFlags", "parent", vVehicleHandlingParent.id)
local vstrDamageFlagsParent = menu.add_feature("strDamageFlags", "parent", vVehicleHandlingParent.id)

menu.add_feature("Load Current Car Flags", "action", vstrDamageFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_vehicle_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	local flags = handlingData.strDamageFlags
	
	for i=1,vstrDamageFlagsParent.child_count do
		local child = vstrDamageFlagsParent.children[i]
		local flag = strDamageFlags[child.data]
		if flag then
			child.on = flags & flag ~= 0
		end
	end
end)

menu.add_feature("Set Current Car Flags", "action", vstrDamageFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_vehicle_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	
	local flags = 0
	for i=1,Parent.child_count do
		local child = vstrDamageFlagsParent.children[i]
		local flag = strDamageFlags[child.data]
		if flag and child.on then
			flags = flags | flag
		end
	end
	
	handlingData.strDamageFlags = flags
end)

local flagNames = {}
for k in pairs(strDamageFlags) do
	flagNames[#flagNames + 1] = k
end
table.sort(flagNames)
for i=1,#flagNames do
	menu.add_feature(flagNames[i], "toggle", vstrDamageFlagsParent.id).data = flagNames[i]
end


menu.add_feature("Load Current Car Flags", "action", vstrModelFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_vehicle_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	local flags = handlingData.strModelFlags
	
	for i=1,vstrModelFlagsParent.child_count do
		local child = Parent.children[i]
		local flag = strModelFlags[child.data]
		if flag then
			child.on = flags & flag ~= 0
		end
	end
end)

menu.add_feature("Set Current Car Flags", "action", vstrModelFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_vehicle_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	
	local flags = 0
	for i=1,Parent.child_count do
		local child = vstrModelFlagsParent.children[i]
		local flag = strModelFlags[child.data]
		if flag and child.on then
			flags = flags | flag
		end
	end
	
	handlingData.strModelFlags = flags
end)

local flagNames = {}
for k in pairs(strModelFlags) do
	flagNames[#flagNames + 1] = k
end
table.sort(flagNames)
for i=1,#flagNames do
	menu.add_feature(flagNames[i], "toggle", vstrModelFlagsParent.id).data = flagNames[i]
end

menu.add_feature("Load Current Car Flags", "action", vStrAdvancedFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_car_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	local flags = handlingData.strAdvancedFlags
	
	for i=1,vStrAdvancedFlagsParent.child_count do
		local child = vStrAdvancedFlagsParent.children[i]
		local flag = strAdvancedFlags[child.data]
		if flag then
			child.on = flags & flag ~= 0
		end
	end
end)

menu.add_feature("Set Current Car Flags", "action", vStrAdvancedFlagsParent.id, function()
	local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_car_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
	
	local flags = 0
	for i=1,vStrAdvancedFlagsParent.child_count do
		local child = vStrAdvancedFlagsParent.children[i]
		local flag = strAdvancedFlags[child.data]
		if flag and child.on then
			flags = flags | flag
		end
	end
	
	handlingData.strAdvancedFlags = flags
end)

local flagNames = {}
for k in pairs(strAdvancedFlags) do
	flagNames[#flagNames + 1] = k
end
table.sort(flagNames)
for i=1,#flagNames do
	menu.add_feature(flagNames[i], "toggle", vStrAdvancedFlagsParent.id).data = flagNames[i]
end

local function SetVehicleHandlingCallback(f,data)
    local pid = player.player_id()
    if not player.is_player_in_any_vehicle(pid) then
        menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
        return
    end
    
    local veh = player.get_player_vehicle(pid)
    local handlingData = vehicle.get_vehicle_handling_data(veh)
    if not handlingData then
        menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
        return
    end
    
    if not handlingData[data] then
        menu.notify("Could not not find data property with name: " .. data, nil, nil, 0xFF0000FF)
        return
    end
    
    handlingData[data] = f.value
end

local function AIHandlingCallback(f, data)
    local pid = player.player_id()
	if not player.is_player_in_any_vehicle(pid) then
		menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
		return
	end
	
	local veh = player.get_player_vehicle(pid)
	local handlingData = vehicle.get_vehicle_handling_data(veh)
	if not handlingData then
		menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
		return
	end
    handlingData[data] = gameplay.get_hash_key(AIHandlingNames [f.value + 1])
end


local function SetCarHandlingDataCallback(f,data)
    local pid = player.player_id()
    if not player.is_player_in_any_vehicle(pid) then
        menu.notify("You're not in a vehicle", nil, nil, 0xFF0000FF)
        return
    end
    
    local veh = player.get_player_vehicle(pid)
    local handlingData = vehicle.get_car_handling_data(veh)
    if not handlingData then
        menu.notify("Could not get handling data. Are you in a vehicle?", nil, nil, 0xFF0000FF)
        return
    end
    
    if not handlingData[data] then
        menu.notify("Could not not find data property with name: " .. data, nil, nil, 0xFF0000FF)
        return
    end
    
    handlingData[data] = f.value
end
--Credit to Gee-Man521#7067 for this one too :)
function set_feat_data(_feat,_data,_min,_max,_mod)
    _feat.data = _data
    _feat.min = _min
    _feat.max = _max
    _feat.mod = _mod
end




function GenerateFeats()
    for k, v in pairs (handlingproperties) do
        local feat = menu.add_feature(v, "action_value_f", vVehicleHandlingParent.id, SetVehicleHandlingCallback)
        local data = v
        set_feat_data(feat, data, -1000000, 1000000, 0.10)
    end

    for k, v in pairs (carhandlingdata) do
        local feat = menu.add_feature(v, "action_value_f", vCarHandlingparent.id, SetCarHandlingDataCallback)
        local data = v
        set_feat_data(feat, data, -1000000, 1000000, 0.10)
    end

	local f = menu.add_feature("AiHandling", "action_value_str", vVehicleHandlingParent.id, AIHandlingCallback)
	f.data = "AIHandling"
	f:set_str_data(AIHandlingNames)
end
GenerateFeats()


